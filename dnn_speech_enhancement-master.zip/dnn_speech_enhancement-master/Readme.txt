# Speech Enhancement using CRNN based multi channel weiner filter

Requirements :

sklearn
soundfile
pytorch
numpy
librosa=0.6.0
soundfile
scipy
GPUtil
json

Step 1. Data preprocessing 

Input : Target, Noise, and Noisy speech directory
Output : STFT, Mask normalization parameters
	 Saved STFT-Mask data for train and test dataset.

python data_preprocessing.py datapreprocessing_config.json

Step 2. training 

Input : Saved STFT-Mask data for train and test dataset.
Output : trained CRNN model

python training.py config_model_blstm.json

Step 3. testing 

Input : test stft-mask data, normalization parameters, trained model
Output : Speech enhanced output wav files saved in directory

python testing.py config_model_blstm.json


