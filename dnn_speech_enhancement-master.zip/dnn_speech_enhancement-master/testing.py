#!/usr/bin/env python
# coding: utf-8

import warnings
warnings.filterwarnings('ignore')

from model import SpeechEnhanceCRNN

import torch
import torch.nn as nn 
import numpy as np
import librosa as lb
import sys
import os
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import soundfile as sf
import fnmatch
import collections
import random
import librosa

from sklearn.utils.extmath import _incremental_mean_and_var
from sklearn.preprocessing.data import _handle_zeros_in_scale

from mask_utils import multichannel_weiner_filter

from model import SpeechEnhanceCRNN, SpeechEnhanceSelfAttentionCRNN

import scipy.stats


def save_wav(y, sr, wav_dir, rir_id):
    nch = y.shape[1]
    for i in range(1,nch+1):
        #print(i)
        str_ = '_output_wav_Ch-%d.wav'%i
        outwavpath = os.path.join(wav_dir, str(rir_id)+str_)
        sf.write(outwavpath, y[:,i-1], samplerate=sr)


def get_data(index):
    y, sr = load_wav_data(index, y_dir, stype='y') 
    s, sr = load_wav_data(index, s_dir, stype='s')
    n, sr = load_wav_data(index, n_dir, stype='n')
    #(y*self.amp).astype('int')*1.0
    y_stft = stft_nchannel_wave(y, win_len, hop_len, nch)
    s_stft = stft_nchannel_wave(s, win_len, hop_len, nch)
    n_stft = stft_nchannel_wave(n, win_len, hop_len, nch)

    mask = target_mask_estimation(s_stft, n_stft)

    return y_stft, mask, y, s, sr



def get_fileid_list(array_file):
    list_ = []
    for i in open(array_file, 'r'):
        list_.append(int(i.strip()))
    return list_

def target_mask_estimation(s_stft, n_stft, sum_of_squares=True):
    if sum_of_squares == True:
        Ms = np.abs(s_stft.astype('float'))/(np.abs(s_stft.astype('float')) + np.abs(n_stft.astype('float'))) # |S_w| / |S_w| + |N_w|
    else:
        Ms = np.abs(s_stft.astype('float'))/np.abs(s_stft.astype('float') + n_stft.astype('float')) # |S_w| / |(S_w + N_w)|

    return Ms


def stft_nchannel_wave(y, win_len=512, win_hop=256, n_channel=3, center=False):
    # Input data parameters
    n_freq = int(win_len / 2 + 1)
    n_frames = int(1 + np.floor((len(y) - win_len) / win_hop))

    y_stft = np.zeros((n_freq, n_frames, n_channel), 'complex')

    if n_channel == 1:
        y_stft = librosa.core.stft(np.ascontiguousarray(y), n_fft=win_len, hop_length=win_hop, center=False)
    else:
        for i_ch in range(n_channel):
            y_stft[:, :, i_ch] = librosa.core.stft(np.ascontiguousarray(y[:, i_ch]), n_fft=win_len, hop_length=win_hop, center=False)


    return np.clip(abs(y_stft), hp.STFT_MIN, hp.STFT_MAX)


def load_wav_data(rir_id, wav_dirpath, nch=3, stype = 'y'):
    wav_data = []
    for i in range(1,nch+1):
        if stype == 's':
            str_ = str(rir_id) +'_target_Ch-%d.wav'%i
        elif stype == 'n':
            str_ = str(rir_id) + '_robovox_Ch-%d.wav'%i
        elif stype == 'y':
            str_ = str(rir_id) + '_Mix-robovox_Ch-%d.wav'%i

        fpath = os.path.join(wav_dirpath,str_)
        y, sr = sf.read(fpath)
        wav_data.append(y)
    wav_data = np.transpose(np.asanyarray(wav_data))

    return wav_data, sr

# extract 21 frames context from stft
def extract_frames(y_stft, mask, frame_size=10, feature_dim=257):
    all_stft = []
    for i in range(y_stft.shape[2]):
        if i>frame_size and i< y_stft.shape[2]-frame_size:
            t_future = y_stft[:,:,i:i+frame_size,:]
            t_past = y_stft[:,:,i-frame_size:i,:]
            #print(t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
        elif i<frame_size and i < y_stft.shape[2]-frame_size:
            t_future = y_stft[:,:,i:i+frame_size,:]
            t_past = y_stft[:,:,:i,:]
            zeros = torch.zeros(1,y_stft.shape[1],frame_size-i,feature_dim)
            t_past = torch.cat([t_past, zeros.double()], dim=2)
            #print(10-i, i, t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
        elif i == frame_size or i == y_stft.shape[2] - frame_size:
            t_future = y_stft[:,:,i:i+frame_size,:]
            t_past = y_stft[:,:,i-frame_size:i,:]

            #print(i, t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
        else:
            t_future = y_stft[:,:,i:y_stft.shape[2],:]
            zeros = torch.zeros(1,y_stft.shape[1],i+frame_size-y_stft.shape[2],feature_dim)
            t_future = torch.cat([t_future, zeros.double()], dim=2)
            t_past = y_stft[:,:,i-frame_size:i,:]

        #print(t_past.shape, y_stft[:,:,i,:].unsqueeze(2).shape, t_future.shape)
        stft = torch.cat([t_past,y_stft[:,:,i,:].unsqueeze(2),t_future], dim=2)

        all_stft.append(stft.numpy())


    all_stft = np.asanyarray(all_stft)
    all_stft = torch.from_numpy(all_stft)

    train_stft, train_mask = all_stft.squeeze(1), mask.permute(2, 1, 0, 3)

    return train_stft, train_mask

# log norm transform 
def log_transform(x, c = 0.0001):
    return np.log(abs(x) + c)


def meanvar_normalise(data):
    dtype = data[0][0].dtype
    last_sample_count = 0
    mean_=0.0
    var_=0.0
    for idx, x in enumerate(data):
        #print(idx, x.shape)
        mean_, var_, _ = _incremental_mean_and_var(x, mean_, var_, last_sample_count)
        last_sample_count += len(x)
    mean_, var_ = mean_.astype(dtype), var_.astype(dtype)
    stddev_ = np.sqrt(var_)
    return mean_, var_, stddev_

def meanvar_scale(x, data_mean, data_stddev):
    return (x - data_mean) / _handle_zeros_in_scale(data_stddev, copy=False)

def meanvar_scaleback(x, data_mean, data_stddev):
    return x*data_stddev + data_mean


def scale_data(data, normparam, nch=3):
    for i in range(nch):
        data[i] = meanvar_scale(data[i], normparam['mean'], normparam['stddev'])
    return data

def scale_back_data(data, normparam, nch=3):
    for i in range(nch):
        data[i] = meanvar_scaleback(data[i], normparam['mean'], normparam['stddev'])
    return data



def main(param):
    y_dir = params['data']['Noisy_dirpath'] # mixture of clean speech and noise dir
    s_dir = params['data']['Target_dirpath'] # clean speech dir
    n_dir = params['data']['Noise_dirpath'] # Noise dir
    y_pred_dir = params['data']['out_wav_dir']
    win_len = params['data']['win_len']
    hop_len = params['data']['hop_len']
    nch = params['data']['nchannel']
    test_array_filepath = params['data']['test_array']
    model_checkpoint_path = params['data']['checkpoint_model_path']
    stft_normparam_path, mask_normparam_path = params['data']['stft_norm_path'], params['data']['mask_norm_path']
    use_cuda = params['model']['use_cuda']
    norm_type = params['data']['norm_type'] # None or mean-var or lognorm-meanvar
    
    if os.path.exists(y_pred_dir) == False:
        os.mkdir(y_pred_dir)

    print('testing started ......')

    test_array = get_fileid_list(test_array_filepath)
    
    mask_normparam = np.load(mask_normparam_path, allow_pickle=True).all()
    stft_normparam = np.load(stft_normparam_path, allow_pickle=True).all()

    model = SpeechEnhanceCRNN(rnn_type, hirarchial, in_channel, filters, kernel_size, 
                              padding, stride, maxpool_size, rnn_hidden_size,rnn_input_size, 
                              output_size, num_rnn_layers, bidirectional)
    
    if torch.cuda.is_available():
        
        import GPUtil # to select single gpu device on grid5000
        import sys
        
        gpu = GPUtil.getAvailable(order = 'memory')[0]
        cuda_gpu_device_id = 'cuda:%d'%gpu
        print('model running on cuda device', cuda_gpu_device_id)
        device = torch.device(cuda_gpu_device_id)
        model = model.to(device)
    else:
        device = torch.device('cpu') # if running on local machine
        model = model.to(device)
    
    model.load_state_dict(torch.load(model_checkpoint_path, map_location=device)) # loading trained model
    model.eval()

    print(len(test_array), 'test_array len')

    for i in test_array:
        y_stft, y_mask, y, s, sr = get_data(i)
        
        y_stft = y_stft.squeeze(0).numpy()
        y_mask = y_mask.squeeze(0).numpy()
        
        if norm_type == 'mean-var':
            y_stft = torch.from_numpy(scale_data(y_stft, stft_normparam)).unsqueeze(0)
            y_mask = torch.from_numpy(scale_data(y_mask, mask_normparam)).unsqueeze(0)
        elif norm_type == 'BC-mean-var':
            y_stft = torch.from_numpy(log_transform(y_stft)).unsqueeze(0)
            y_mask = torch.from_numpy(scale_data(y_mask, mask_normparam)).unsqueeze(0)
        elif norm_type == 'None':
            y_stft = torch.from_numpy(abs(y_stft)).unsqueeze(0)
            y_mask = torch.from_numpy(y_mask).unsqueeze(0)
        
        
        y_stft = y_stft.unsqueeze(0).permute(0,3,2,1)
        y_mask = y_mask.unsqueeze(0).permute(0,3,2,1)
        y_stft, y_mask = extract_frames(y_stft, y_mask)


        with torch.no_grad():
            if use_cuda:
                y_stft, y_mask = y_stft.cuda(), y_mask.cuda()
                model = model.cuda()
            y_stft = y_stft.float()
            pred_mask = model(y_stft) # predicting mask for channel 1 using stft from 3 channels 
            pred_mask = torch.cat([pred_mask, pred_mask, pred_mask], dim=1).squeeze(2) # concatenating 
            pred_mask = pred_mask.permute(1,2,0).detach().cpu().numpy()
            
            if norm_type == 'mean-var' or 'BC-mean-var':
                pred_mask = scale_back_data(pred_mask, mask_normparam)
            
            
            print(pred_mask.shape, y.shape) # y : noisy mixture, pred_mask: crnn predicted mask
            y_out = multichannel_weiner_filter(y, pred_mask, win_len, hop_len, mu, lambda_cor)

            save_wav(y_out, sr, y_pred_dir, i)




if __name__ == "__main__":
    config_filepath = sys.argv[1] # argument 1 config file
    
    if os.path.exists(config_filepath) == False:
        print('Please check config filepath', config_filepath)
    else:
        with open(config_filepath, 'r') as f:
            params = json.load(f)
    
        main(params)
