import numpy as np
import librosa as lb
import scipy.linalg
import sys


eps = sys.float_info.epsilon
eta = 1e6


def spatial_correlation_matrix(Rxx, x, lambda_cor=0.95, M=None):
    """
    Return spatial correlation matrix computed as exponentially smoothing of :
            - if M is None: x*x.T
                            so Rxx = lambda * Rxx + (1 - lambda)x*x.T
              x should then be an estimation of the signal of which one wants the Rxx

            - if M is not None: M*x*x.T
              x is then the mixture
    :param Rxx:             Previous estimation of Rxx
    :param x:               Signal (estimation of noise/speech if M is none; mixture otherwise)
    :param lambda_cor:      Smoothing parameter
    :param M:               Mask. If None, x is the estimation of the signal of which one wants the Rxx.
    :return: Rxx            Current eximation of Rxx
    """
    if M is None:
        Rxx = lambda_cor * Rxx + (1 - lambda_cor) * np.outer(x, np.conjugate(x).T)
    else:
        Rxx = lambda_cor * Rxx + M * (1 - lambda_cor) * np.outer(x, np.conjugate(x).T)
    return Rxx



def truncated_eye(N, j, k=0):
    """
    Create a NxN matrix with k consecutive ones in the diagonal.
    :param N:   (int) Dimension of output matrix
    :param j:   (int) Number of ones in the diagonal
    :param k:   (int) Diagonal in question (k>0 shifts the diagonal to a sub-diagonal)
    :return: A truncated eye matrix
    """
    v1 = np.ones((j, ))
    v0 = np.zeros((N - j, ))

    return np.diag(np.concatenate((v1, v0), axis=0), k=k)






def wiener_mask(x, n, power=2):
    """Returns the ideal wiener mask.

    Arguments:
        - x:        speech spectrogram (real values)
        - n:        noise spectrogram (real values; same size as x)
        - power:    power of SNR in gain computation [2]
    Output:
        - wm: wiener mask values between 0 and 1
    """
    xi = (x / n) ** power
    wf = xi / (1 + xi)
    return wf


def masking(y, s, n, m, win_len=512, win_hop=256):
    y_stft = lb.core.stft(y, n_fft=win_len, hop_length=win_hop, center=True)
    s_stft = lb.core.stft(s, n_fft=win_len, hop_length=win_hop, center=True)
    n_stft = lb.core.stft(n, n_fft=win_len, hop_length=win_hop, center=True)

    m = np.pad(m, ((0, 0), (1, 1)), 'reflect')
    y_m = m*y_stft
    s_m = m*s_stft
    n_m = m*n_stft

    y_f = lb.core.istft(y_m, hop_length=win_hop, win_length=win_len, center=True, length=len(y))
    s_f = lb.core.istft(s_m, hop_length=win_hop, win_length=win_len, center=True, length=len(s))
    n_f = lb.core.istft(n_m, hop_length=win_hop, win_length=win_len, center=True, length=len(n))

    return y_f, s_f, n_f


def multichannel_weiner_filter(y, s, n, m, win_len=512, win_hop=256, recompute_mask=False):
    """
    Batch Multichannel Wiener filter, i.e. the covariance matrices are computed from the whole signal.
    Inputs are signal arrays, with one column per channel
    :param y:               Array of mixture signals
    :param s:
    :param n:
    :param m:               Masks list. One per signal
    :param win_len:
    :param win_hop:
    :param recompute_mask:  Whether to recompute mask as wiener(S, N). If false, input is kep [False]
    :return:
    """
    # Input data parameters
    n_freq = int(win_len / 2 + 1)
    n_frames = int(1 + np.floor((len(y) - win_len) / win_hop))
    n_ch = y.shape[1]
    # Initialize variables
    y_stft = np.zeros((n_freq, n_frames, n_ch), 'complex')
    s_stft = np.zeros((n_freq, n_frames, n_ch), 'complex')
    n_stft = np.zeros((n_freq, n_frames, n_ch), 'complex')
    s_stft_hat = np.zeros((n_freq, n_frames, n_ch), 'complex')
    n_stft_hat = np.zeros((n_freq, n_frames, n_ch), 'complex')
    r_ss = np.zeros((n_freq, n_ch, n_ch), 'complex')
    r_nn = np.zeros((n_freq, n_ch, n_ch), 'complex')
    w = np.zeros((n_freq, n_frames, n_ch), 'complex')
    y_filt = np.zeros((n_freq, n_frames, n_ch), 'complex')
    s_filt = np.zeros((n_freq, n_frames, n_ch), 'complex')
    n_filt = np.zeros((n_freq, n_frames, n_ch), 'complex')
    y_out = np.zeros(y.shape)
    s_out = np.zeros(y.shape)
    n_out = np.zeros(y.shape)

    for i_ch in range(n_ch):
        y_stft[:, :, i_ch] = lb.core.stft(y[:, i_ch], n_fft=win_len, hop_length=win_hop, center=False)
        s_stft[:, :, i_ch] = lb.core.stft(s[:, i_ch], n_fft=win_len, hop_length=win_hop, center=False)
        n_stft[:, :, i_ch] = lb.core.stft(n[:, i_ch], n_fft=win_len, hop_length=win_hop, center=False)

        # Input estimation
        if recompute_mask:
            m[i_ch] = wiener_mask(abs(s_stft[:, :, i_ch]), abs(n_stft[:, :, i_ch]), power=1)
        s_stft_hat[:, :, i_ch] = m[i_ch] * y_stft[:, :, i_ch]
        n_stft_hat[:, :, i_ch] = (1 - m[i_ch]) * y_stft[:, :, i_ch]

    # Compute Rx, Rn with mask
    for f in range(n_freq):
        phi_s_f = [[] for it in range(n_frames)]  # Covariance matrix at every frame
        phi_n_f = [[] for it in range(n_frames)]  # Covariance matrix at every frame
        
        for t in range(n_frames):
            phi_s_f[t] = np.outer(s_stft_hat[f, t, :], np.conjugate(s_stft_hat[f, t, :]).T)
            phi_n_f[t] = np.outer(n_stft_hat[f, t, :], np.conjugate(n_stft_hat[f, t, :]).T)
        
        # computing global Rss and Rnn
        r_ss[f] = np.mean(np.array(phi_s_f), axis=0)
        r_nn[f] = np.mean(np.array(phi_n_f), axis=0)
        
        # filter estimation for each f
        w[f] = np.linalg.lstsq(r_nn[f, :, :] + r_ss[f, :, :], r_ss[f, :, :], rcond=None)[0][:, 0]
        
        # filtering
        for i_frame in range(n_frames):
            y_filt[f, i_frame, :] = np.matmul(np.conjugate(w[f, i_frame, :]), y_stft[f, i_frame, :])
            s_filt[f, i_frame, :] = np.matmul(np.conjugate(w[f, i_frame, :]), s_stft[f, i_frame, :])
            n_filt[f, i_frame, :] = np.matmul(np.conjugate(w[f, i_frame, :]), n_stft[f, i_frame, :])

    for i_ch in range(n_ch):
        y_out[:, i_ch] = lb.core.istft(np.pad(y_filt[:, :, i_ch], ((0, 0), (1, 1)), 'reflect'),
                                       hop_length=win_hop, win_length=win_len, center=True, length=len(y))
        s_out[:, i_ch] = lb.core.istft(np.pad(s_filt[:, :, i_ch], ((0, 0), (1, 1)), 'reflect'),
                                       hop_length=win_hop, win_length=win_len, center=True, length=len(y))
        n_out[:, i_ch] = lb.core.istft(np.pad(n_filt[:, :, i_ch], ((0, 0), (1, 1)), 'reflect'),
                                       hop_length=win_hop, win_length=win_len, center=True, length=len(y))

    return y_out, s_out, n_out, m
