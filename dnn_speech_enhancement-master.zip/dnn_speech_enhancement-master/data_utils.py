#!/usr/bin/env python
# coding: utf-8


import torch
import torch.nn as nn 
import numpy as np
import librosa as lb
import os
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import soundfile as sf

import collections
import random

import librosa
import pickle

from sklearn.utils.extmath import _incremental_mean_and_var
from sklearn.preprocessing.data import _handle_zeros_in_scale


# In[45]:


def meanvar_normalise(data):
    dtype = data[0][0].dtype
    last_sample_count = 0
    mean_=0.0
    var_=0.0
    for idx, x in enumerate(data):
        #print(idx, x.shape)
        mean_, var_, _ = _incremental_mean_and_var(x, mean_, var_, last_sample_count)
        last_sample_count += len(x)
    mean_, var_ = mean_.astype(dtype), var_.astype(dtype)
    stddev_ = np.sqrt(var_)
    return mean_, var_, stddev_

def meanvar_scale(x, data_mean, data_stddev):
    return (x - data_mean) / _handle_zeros_in_scale(data_stddev, copy=False)

def meanvar_scaleback(x, data_mean, data_stddev):
    return x*data_stddev + data_mean




# In[ ]:





class SpeechEnhancementDataset(Dataset):
    

    def __init__(self,
                 stft_mask_dir, stft_normparam_path, mask_normparam_path, array_filepath, norm_type, frame_size=10, feature_dim=257):
        

        self.stft_mask_dir = stft_mask_dir
        self.mask_normparam = np.load(mask_normparam_path, allow_pickle=True).all()
        self.stft_normparam = np.load(stft_normparam_path, allow_pickle=True).all()
        self.norm_type = norm_type
        
        self.array_filepath = array_filepath        
        self.frame_size = frame_size
        self.feature_dim = feature_dim
        
        self.data_files = sorted(self.get_fileid_list(self.array_filepath))
        
    #stft normparam
    def get_fileid_list(self, array_file):
        list_ = []
        for i in open(array_file, 'r'):
            list_.append(int(i.strip()))
        return list_
    
    def scale_data(self, data, normparam, nch=3):
        for i in range(nch):
            data[i] = meanvar_scale(data[i], normparam['mean'], normparam['stddev'])
        return data

    def scale_back_data(self, data, normparam, nch=3):
        for i in range(nch):
            data[i] = meanvar_scaleback(data[i], normparam['mean'], normparam['stddev'])
        return data
    
    
    def log_transform(self, x, c = 0.0001):
        return np.log(abs(x) + c)


    
    # extracting 21 frames context from stft
    def extract_frames(self, y_stft, mask):
        all_stft = []
        for i in range(y_stft.shape[2]):
            if i>self.frame_size and i< y_stft.shape[2]-self.frame_size:
                t_future = y_stft[:,:,i:i+self.frame_size,:]
                t_past = y_stft[:,:,i-self.frame_size:i,:]
                #print(t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
            elif i<self.frame_size and i < y_stft.shape[2]-self.frame_size:
                t_future = y_stft[:,:,i:i+self.frame_size,:]
                t_past = y_stft[:,:,:i,:]
                zeros = torch.zeros(1,y_stft.shape[1],self.frame_size-i,self.feature_dim)
                t_past = torch.cat([t_past, zeros.double()], dim=2)
                #print(10-i, i, t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
            elif i == self.frame_size or i == y_stft.shape[2] - self.frame_size:
                t_future = y_stft[:,:,i:i+self.frame_size,:]
                t_past = y_stft[:,:,i-self.frame_size:i,:]

                #print(i, t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
            else:
                t_future = y_stft[:,:,i:y_stft.shape[2],:]
                zeros = torch.zeros(1,y_stft.shape[1],i+self.frame_size-y_stft.shape[2],self.feature_dim)
                t_future = torch.cat([t_future, zeros.double()], dim=2)
                t_past = y_stft[:,:,i-self.frame_size:i,:]

            #print(t_past.shape, y_stft[:,:,i,:].unsqueeze(2).shape, t_future.shape)
            stft = torch.cat([t_past,y_stft[:,:,i,:].unsqueeze(2),t_future], dim=2)

            all_stft.append(stft.numpy())


        all_stft = np.asanyarray(all_stft)
        all_stft = torch.from_numpy(all_stft)

        train_stft, train_mask = all_stft.squeeze(1), mask.permute(2, 1, 0, 3)

        return train_stft, train_mask

        
    def __len__(self):
        return len(self.data_files)

    def __getitem__(self, index):
        
        data = torch.load(os.path.join(self.stft_mask_dir,str(self.data_files[index])+'_stft_mask.pt'))
        
        y_stft = data['stft'].squeeze(0).numpy()
        y_mask = data['mask'].squeeze(0).numpy()
        
        #print(y_stft.shape)
        
        if self.norm_type == 'mean-var': # mean-var normalization
            y_stft = torch.from_numpy(self.scale_data(y_stft, self.stft_normparam)).unsqueeze(0)
            y_mask = torch.from_numpy(self.scale_data(y_mask, self.mask_normparam)).unsqueeze(0)
        elif self.norm_type == 'BC-mean-var': # log normalization
            y_stft = torch.from_numpy(self.log_transform(y_stft)).unsqueeze(0)
            y_mask = torch.from_numpy(self.scale_data(y_mask, self.mask_normparam)).unsqueeze(0)
        elif self.norm_type == 'None': # no normalization
            y_stft = torch.from_numpy(abs(y_stft)).unsqueeze(0)
            y_mask = torch.from_numpy(y_mask).unsqueeze(0)
        
        #print(y_mask.shape, y_stft.shape)
        
        sample = {'stft':y_stft, 'mask': y_mask}
        
        return sample



def collate_fn_speech_enhancement(batch):

    # Puts each data field into a tensor with outer dimension batch size
    if isinstance(batch[0], collections.Mapping):
        #print(len(batch))

        stft = [d['stft'] for d in batch]
        mask = [d['mask'] for d in batch]
        
        
        return stft[0], mask[0]

    raise TypeError(("batch must contain tensors, numbers, dicts or lists; found {}"
                     .format(type(batch[0]))))




def get_speech_enhancement_dataset(stft_dir, stft_normparam_path, mask_normparam_path, array_filepath, norm_type):
    return SpeechEnhancementDataset(stft_dir, stft_normparam_path, mask_normparam_path, array_filepath, norm_type)
    





# In[53]:


#array_filepath = 'train_array_robovox.txt'
#stft_dir = './stft_mask/'
#stft_normparam_path = 'stft_normparam.npy'
#mask_normparam_path = 'mask_normparam.npy'
#norm_type = 'None'


# In[54]:


#dataset = get_speech_enhancement_dataset(stft_dir, stft_normparam_path, mask_normparam_path, array_filepath, norm_type)


# In[55]:


#dataloader = DataLoader(dataset, batch_size=hp.batch_size, shuffle=True, #collate_fn=collate_fn_speech_enhancement, drop_last=True, num_workers=4)


# In[56]:


#for i, data in enumerate(dataloader):
#    stft, mask = data
#    #stft, mask = dataset.extract_frames(stft, mask)
#    #print(stft.shape, mask.shape)
#    #stft, mask = dataset.extract_frames(stft.unsqueeze(0), mask.unsqueeze(0))
#    print(stft.shape, mask.shape)
    


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




