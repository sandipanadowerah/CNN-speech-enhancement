#!/usr/bin/env python
# coding: utf-8

# In[1]:


import torch
import torch.nn as nn
import numpy as np
import os
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

import matplotlib.pyplot as plt
import sys
import os
import torch.multiprocessing as mp
import torch
import torch.nn as nn
import torch.distributed as dist

import json

from data_utils import get_speech_enhancement_dataset, collate_fn_speech_enhancement
from model import SpeechEnhanceCRNN, SpeechEnhanceSelfAttentionCRNN


def main(params):
    test_array_filepath = params['data']['test_array']
    train_array_filepath = params['data']['train_array']
    nch = params['data']['nchannel']
    checkpoint_interval = params['data']['checkpoint_interval']
    model_checkpoint_dir = params['data']['model_dir']
    norm_type = params['data']['norm_type']
    stft_mask_dir = params['data']['stft_mask_dir']
    stft_normparam_path = params['data']['stft_norm_path']
    mask_normparam_path = params['data']['mask_norm_path']

	# pytorch dataset and dataloader for train and test data
    test_dataset = get_speech_enhancement_dataset(stft_mask_dir, stft_normparam_path, mask_normparam_path, test_array_filepath, norm_type)

    train_dataset = get_speech_enhancement_dataset(stft_mask_dir, stft_normparam_path, mask_normparam_path, train_array_filepath, norm_type)


    train_dataloader = DataLoader(train_dataset, batch_size=1, shuffle=True, collate_fn=collate_fn_speech_enhancement, drop_last=True, num_workers=4)

    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=True, collate_fn=collate_fn_speech_enhancement, drop_last=True, num_workers=4)

    dataloader = {'train':train_dataloader, 'test':test_dataloader}

    if model_checkpoint_dir != '' and os.path.exists(model_checkpoint_dir) == False:
        os.mkdir(model_checkpoint_dir)

    rnn_type = params['model']['rnn_type']
    hirarchial = params['model']['hirarchial']
    in_channel= params['model']['in_channel'] 
    filters= params['model']['filters']
    kernel_size= params['model']['kernal_size']
    padding= params['model']['padding']
    stride= params['model']['stride'] 
    maxpool_size= (params['model']['maxpool'][0], params['model']['maxpool'][1]) 
    rnn_hidden_size= params['model']['rnn_hidden_size']
    rnn_input_size= params['model']['rnn_input_size']
    output_size=params['model']['output_size']
    num_rnn_layers=params['model']['rnn_layers']
    bidirectional=params['model']['bidirectional']
    learning_rate = params['model']['learning_rate']
    weight_decay =  params['model']['weight_decay']
    num_epochs =  params['model']['num_epochs']
    checkpoint_model_path = params['data']['checkpoint_model_path']
    checkpoint_optimizer_path = params['data']['checkpoint_optimizer_path']
    use_cuda = bool(params['model']['use_cuda'])


    model = SpeechEnhanceCRNN(rnn_type, hirarchial, in_channel, filters, kernel_size, 
                              padding, stride, maxpool_size, rnn_hidden_size,rnn_input_size, 
                              output_size, num_rnn_layers, bidirectional)

#    model = SpeechEnhanceSelfAttentionCRNN(rnn_type, hirarchial, True, in_channel, filters, kernel_size, 
#                              padding, stride, maxpool_size, rnn_hidden_size,rnn_input_size, 
#                              output_size, num_rnn_layers, bidirectional)


    model = model.double()
    print(model)
    criterion = nn.MSELoss() # MSE loss criterion

    optimizer = torch.optim.RMSprop(model.parameters(), lr=learning_rate,
                                     weight_decay=weight_decay) # RMS prop optimizer
    
    if torch.cuda.is_available():
        
        import GPUtil # for selecting gpu device id for grid5000
        import sys
        gpu = GPUtil.getAvailable(order = 'memory')[0]

        cuda_gpu_device_id = 'cuda:%d'%gpu
        device = torch.device(cuda_gpu_device_id)
        
        gpu = GPUtil.getAvailable(order = 'memory')[0]

        cuda_gpu_device_id = 'cuda:%d'%gpu
        print('model running on cuda device', cuda_gpu_device_id)
        device = torch.device(cuda_gpu_device_id)
        model = model.to(device)
        
        for state in optimizer.state.values():
            for k, v in state.items():
                if torch.is_tensor(v):
                    state[k] = v.to(device)
    else:
        device = torch.device('cpu') # to run on local machine
        model = model.to(device)
        
    if checkpoint_model_path != '' and checkpoint_optimizer_path != '': # for restoring training process
        model.load_state_dict(torch.load(checkpoint_model_path, map_location=device))
        optimizer.load_state_dict(torch.load(checkpoint_optimizer_path, map_location=device))
        print('model, optimizer loaded .....')
        

    print('Training started .......')

    loss_history = {"train": [], "test": []}
    for epoch in range(num_epochs):
        for phase in ['train', 'test']:

            if phase == "train":
                model.train()
            else:
                model.eval()

            running_loss = 0.0

            for i, data in enumerate(dataloader[phase]):
                y_stft, y_mask = data
                #print(y_stft.shape, y_mask.shape)
                y_stft, y_mask = train_dataset.extract_frames(y_stft, y_mask)
                #extracting 21 frames context from stft

                if use_cuda:
                    y_stft, y_mask = y_stft.to(device), y_mask.to(device)

                pred_mask = model(y_stft.double())

                loss = criterion(pred_mask, y_mask[:,:1,:,:])

                #computing mse loss
                #print(i, y_stft.shape, y_mask.shape, loss)
                # ===================backward====================

                optimizer.zero_grad()

                if phase == 'train':
                    loss.backward()
                    optimizer.step()

                running_loss += loss.item()
            loss_history[phase].append(running_loss / len(dataloader[phase]))
            print('loss', phase, running_loss , len(dataloader[phase]), running_loss/len(dataloader[phase]))

        if epoch % checkpoint_interval == 0:
            torch.save(model.state_dict(), os.path.join(model_checkpoint_dir,'SpeechEnhancement_Model_Epoch_'+str(epoch+1)+'.pt'))
            torch.save(optimizer.state_dict(), os.path.join(model_checkpoint_dir,'SpeechEnhancement_Optimizer_Epoch_'+str(epoch+1)+'.pt'))


    print(loss_history)
    plt.plot(loss_history["train"], linewidth=2, label="Train loss")
    plt.plot(loss_history["test"], linewidth=2, label="Test loss")
    plt.legend(prop={"size": 16})
    plt.savefig('Speech_Enhancement_'+architecture+'train_test_loss_plot.png')	


if __name__ == "__main__":
    config_filepath = sys.argv[1] # argument 1 config file
    
    if os.path.exists(config_filepath) == False:
        print('Please check config filepath', config_filepath)
    else:
        with open(config_filepath, 'r') as f:
            params = json.load(f)
    
        main(params)
