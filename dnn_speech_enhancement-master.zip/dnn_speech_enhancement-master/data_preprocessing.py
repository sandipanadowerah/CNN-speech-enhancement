#!/usr/bin/env python
# coding: utf-8

import sys
import torch
import torch.nn as nn 
import numpy as np
import librosa
import librosa as lb
import os
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import soundfile as sf
import collections
import random
import pickle
import json

from sklearn.utils.extmath import _incremental_mean_and_var
from sklearn.preprocessing.data import _handle_zeros_in_scale


# In[45]:


def meanvar_normalise(data):
    dtype = data[0][0].dtype
    last_sample_count = 0
    mean_=0.0
    var_=0.0
    for idx, x in enumerate(data):
        #print(idx, x.shape)
        mean_, var_, _ = _incremental_mean_and_var(x, mean_, var_, last_sample_count)
        last_sample_count += len(x)
    mean_, var_ = mean_.astype(dtype), var_.astype(dtype)
    stddev_ = np.sqrt(var_)
    return mean_, var_, stddev_

def meanvar_scale(x, data_mean, data_stddev):
    return (x - data_mean) / _handle_zeros_in_scale(data_stddev, copy=False)

def meanvar_scaleback(x, data_mean, data_stddev):
    return x*data_stddev + data_mean

def znorm_data(y, mean_, stddev_, scale_back, nch=3):
    data = []
    for i in range(1,nch+1):
        if scale_back == False:
            data.append(meanvar_scale(y[i-1], mean_.all()[i], stddev_.all()[i]))
        else:
            data.append(meanvar_scaleback(y[i-1], mean_.all()[i], stddev_.all()[i]))
    data = np.asanyarray(data)
    
    return data


# In[47]:


# step 1. Define dataset class
# step 2. Define __collate__() class
# step 3. Define dataloader class
# assumption sampling rate for y, s, and n are same
class SpeechEnhancementDataset(Dataset):
    

    def __init__(self,
                 y_dirpath, s_dirpath, n_dirpath, array_filepath, nch=3, frame_size=10, feature_dim=257):
        
        self.y_dir = y_dirpath
        self.s_dir = s_dirpath
        self.n_dir = n_dirpath
        self.win_len = 512
        self.hop_len = 256
        self.array_filepath = array_filepath
        self.nch = nch
        self.STFT_MIN, self.STFT_MAX = 1e-6, 1e3
        self.frame_size = frame_size
        self.feature_dim = feature_dim
        self.data_files = sorted(self.get_fileid_list(self.array_filepath))
        
    #stft normparam
    def get_fileid_list(self, array_file):
        list_ = []
        for i in open(array_file, 'r'):
            list_.append(int(i.strip()))
        return list_

    # extracting 21 frames context from stft

    def extract_frames(self, y_stft, mask):
        all_stft = []
        for i in range(y_stft.shape[2]):
            if i>self.frame_size and i< y_stft.shape[2]-self.frame_size:
                t_future = y_stft[:,:,i:i+self.frame_size,:]
                t_past = y_stft[:,:,i-self.frame_size:i,:]
                #print(t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
            elif i<self.frame_size and i < y_stft.shape[2]-self.frame_size:
                t_future = y_stft[:,:,i:i+self.frame_size,:]
                t_past = y_stft[:,:,:i,:]
                zeros = torch.zeros(1,y_stft.shape[1],self.frame_size-i,self.feature_dim)
                t_past = torch.cat([t_past, zeros.double()], dim=2)
                #print(10-i, i, t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
            elif i == self.frame_size or i == y_stft.shape[2] - self.frame_size:
                t_future = y_stft[:,:,i:i+self.frame_size,:]
                t_past = y_stft[:,:,i-self.frame_size:i,:]

                #print(i, t_past.shape, t_future.shape, y_stft[:,:,i,:].unsqueeze(0).shape)
            else:
                t_future = y_stft[:,:,i:y_stft.shape[2],:]
                zeros = torch.zeros(1,y_stft.shape[1],i+self.frame_size-y_stft.shape[2],self.feature_dim)
                t_future = torch.cat([t_future, zeros.double()], dim=2)
                t_past = y_stft[:,:,i-self.frame_size:i,:]

            #print(t_past.shape, y_stft[:,:,i,:].unsqueeze(2).shape, t_future.shape)
            stft = torch.cat([t_past,y_stft[:,:,i,:].unsqueeze(2),t_future], dim=2)

            all_stft.append(stft.numpy())


        all_stft = np.asanyarray(all_stft)
        all_stft = torch.from_numpy(all_stft)

        train_stft, train_mask = all_stft.squeeze(1), mask.permute(2, 1, 0, 3)

        return train_stft, train_mask

    def load_wav_data(self, rir_id, wav_dirpath, nch=3, stype = 'y'):
        wav_data = []
        for i in range(1,nch+1):
            if stype == 's':
                str_ = str(rir_id) +'_target_Ch-%d.wav'%i
            elif stype == 'n':
                str_ = str(rir_id) + '_robovox_Ch-%d.wav'%i
            elif stype == 'y':
                str_ = str(rir_id) + '_Mix-robovox_Ch-%d.wav'%i

            fpath = os.path.join(wav_dirpath,str_)
            y, sr = sf.read(fpath)
            wav_data.append(y)
        wav_data = np.transpose(np.asanyarray(wav_data))

        return wav_data, sr
    
    def get_data(self, index):
        y, sr = self.load_wav_data(index, self.y_dir, stype='y') 
        s, sr = self.load_wav_data(index, self.s_dir, stype='s')
        n, sr = self.load_wav_data(index, self.n_dir, stype='n')

        y_stft = self.stft_nchannel_wave(y, self.win_len, self.hop_len, self.nch)
        s_stft = self.stft_nchannel_wave(s, self.win_len, self.hop_len, self.nch)
        n_stft = self.stft_nchannel_wave(n, self.win_len, self.hop_len, self.nch)

        mask = self.target_mask_estimation(abs(s_stft), abs(n_stft))

        return y_stft, mask
    
    def target_mask_estimation(self, s_stft, n_stft, sum_of_squares=True):
        if sum_of_squares == True:
            Ms = np.square(np.abs(s_stft))/np.square(np.abs(s_stft)) + np.square(np.abs(n_stft)) # |S_w|^2 / |S_w|^2 + |N_w|^2
        else:
            Ms = np.abs(s_stft.astype('float'))/np.abs(s_stft.astype('float') + n_stft.astype('float')) # |S_w| / |(S_w + N_w)|

        return Ms
    
    def stft_nchannel_wave(self, y, win_len, win_hop, n_channel, center=False):
        # Input data parameters
        n_freq = int(win_len / 2 + 1)
        n_frames = int(1 + np.floor((len(y) - win_len) / win_hop))

        y_stft = np.zeros((n_freq, n_frames, n_channel), 'complex')

        if n_channel == 1:
            y_stft = librosa.core.stft(np.ascontiguousarray(y), n_fft=win_len, hop_length=win_hop, center=False)
        else:
            for i_ch in range(n_channel):
                y_stft[:, :, i_ch] = librosa.core.stft(np.ascontiguousarray(y[:, i_ch]), n_fft=win_len, hop_length=win_hop, center=False)


        return np.clip(abs(y_stft), self.STFT_MIN, self.STFT_MAX)
        
    def __len__(self):
        return len(self.data_files)

    def __getitem__(self, index):
        
        y_stft, y_mask = self.get_data(self.data_files[index])
        
        sample = {'stft':y_stft, 'mask': y_mask, 'index': self.data_files[index]}
        
        return sample

# In[48]:


def collate_fn_speech_enhancement(batch):

    # Puts each data field into a tensor with outer dimension batch size
    if isinstance(batch[0], collections.Mapping):
        #print(len(batch))

        stft = [d['stft'] for d in batch]
        mask = [d['mask'] for d in batch]
        index = [d['index'] for d in batch]
        
        stft = torch.from_numpy(abs(np.asanyarray(stft, dtype=np.float)))
        mask = torch.from_numpy(np.asanyarray(mask, dtype=np.float))
        
        
        return stft.permute(0,3,2,1), mask.permute(0,3,2,1), index

    raise TypeError(("batch must contain tensors, numbers, dicts or lists; found {}"
                     .format(type(batch[0]))))


# In[49]:


def get_speech_enhancement_preprocessing_dataset(y_dirpath, s_dirpath, n_dirpath, array_filepath):
    return SpeechEnhancementDataset(y_dirpath, s_dirpath, n_dirpath, array_filepath)





def main(params):
    
    y_dirpath = params['data']['Noisy_dirpath'] # Mixture of clean speech and noise dir
    s_dirpath = params['data']['Target_dirpath'] # Clean speech dir
    n_dirpath = params['data']['Noise_dirpath'] # Noise speech dir
    train_array_filepath = params['data']['train_array']
    test_array_filepath = params['data']['test_array']
    stft_normparam_path = params['data']['stft_norm_path'] # stft_normalization file
    mask_normparam_path = params['data']['mask_norm_path'] # mask_normalization file

    stft_mask_dirpath = params['data']['stft_mask_dir'] # saving precomputed stft and mask for training

    if os.path.exists(stft_mask_dirpath) == False:
        os.mkdir(stft_mask_dirpath)
    
    
    train_dataset = get_speech_enhancement_preprocessing_dataset(y_dirpath, s_dirpath, n_dirpath, train_array_filepath)
    train_dataloader = DataLoader(train_dataset, batch_size=1, shuffle=True, collate_fn=collate_fn_speech_enhancement, drop_last=True, num_workers=6)

    test_dataset = get_speech_enhancement_preprocessing_dataset(y_dirpath, s_dirpath, n_dirpath, test_array_filepath)
    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=True, collate_fn=collate_fn_speech_enhancement, drop_last=True, num_workers=6)

    last_stft_count = 0
    last_mask_count = 0
    mean_stft=0.0
    var_stft=0.0
    mean_mask=0.0
    var_mask=0.0

    for i, data in enumerate(train_dataloader):
        y_stft, mask, index = data
        #stft, mask = dataset.extract_frames(y_stft, mask)
        print(y_stft.shape, mask.shape, str(index[0])+'_stft_mask.pt')

        torch.save({'stft':y_stft, 'mask':mask}, os.path.join(stft_mask_dirpath ,str(index[0])+'_stft_mask.pt'))


        y_stft = y_stft.numpy().reshape(-1, 257)
        y_mask = mask.numpy().reshape(-1, 257)
        stft_dtype = y_stft[0][0].dtype
        mask_dtype = y_mask[0][0].dtype
        #estimating mean-var norm parameters
        mean_stft, var_stft, _ = _incremental_mean_and_var(y_stft, mean_stft, var_stft, last_stft_count)
        mean_mask, var_mask, _ = _incremental_mean_and_var(y_mask, mean_mask, var_mask, last_mask_count)

        last_stft_count += len(y_stft)
        last_mask_count += len(y_mask)

    mean_stft, var_stft = mean_stft.astype(stft_dtype), var_stft.astype(stft_dtype)
    stddev_stft = np.sqrt(var_stft.astype(stft_dtype))

    mean_mask, var_mask = mean_mask.astype(mask_dtype), var_mask.astype(mask_dtype)
    stddev_mask = np.sqrt(var_mask.astype(mask_dtype))


    mask_normparam = {'mean':mean_mask, 'var':var_mask, 'stddev': stddev_mask}

    stft_normparam = {'mean':mean_stft, 'var':var_stft, 'stddev': stddev_stft}

    np.save(stft_normparam_path, stft_normparam, allow_pickle=True)
    np.save(mask_normparam_path, mask_normparam, allow_pickle=True)
    
    # saving stft-mask data in single file for train and test dataset
    for i, data in enumerate(train_dataloader):
        y_stft, mask, index = data
        #stft, mask = dataset.extract_frames(y_stft, mask)
        print(y_stft.shape, mask.shape, str(index[0])+'_stft_mask.pt')    


    for i, data in enumerate(test_dataloader):
        y_stft, mask, index = data
        #stft, mask = dataset.extract_frames(y_stft, mask)
        print(y_stft.shape, mask.shape, str(index[0])+'_stft_mask.pt')

        torch.save({'stft':y_stft, 'mask':mask}, os.path.join(stft_mask_dirpath ,str(index[0])+'_stft_mask.pt'))


        
if __name__ == "__main__":
    config_filepath = sys.argv[1] # argument 1
    
    if os.path.exists(config_filepath) == False:
        print('Please check config filepath', config_filepath)
    else:
        print('data processing step started ...')
        with open(config_filepath, 'r') as f:
            params = json.load(f)
    
        main(params)
