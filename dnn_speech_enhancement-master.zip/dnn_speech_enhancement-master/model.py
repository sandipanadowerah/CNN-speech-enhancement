#!/usr/bin/env python
# coding: utf-8

import torch
import torch.nn as nn

# CRNN
# kernal_size 3x3, stride 1x1 relu filter = [32,64,64], maxpool 4x1
# conv2d -> batch_norm -> maxpool     LAYER 1
# conv2d -> batch_norm -> maxpool     LAYER 2
# conv2d -> batch_norm -> maxpool     LAYER 3

# RNN lstm, 256 hidden units
# FF 256 x 257

# Hirarchial CRNN
# kernal_size 3x3, stride 1x1 relu filter = [32,64,64], maxpool 4x1
# conv2d -> batch_norm -> maxpool     LAYER 1
# conv2d -> batch_norm -> maxpool     LAYER 2
# conv2d -> batch_norm -> maxpool     LAYER 3

# RNN1 lstm, 256 hidden units
# FF1 256 x 257

# RNN2 lstm, 256 hidden units
# FF2 256 x 257

# Self attention CRNN
# kernal_size 3x3, stride 1x1 relu filter = [32,64,64], maxpool 4x1
# selfatten as enocder		      LAYER 0
# conv2d -> batch_norm -> maxpool     LAYER 1
# conv2d -> batch_norm -> maxpool     LAYER 2
# conv2d -> batch_norm -> maxpool     LAYER 3

# RNN1 lstm, 256 hidden units
# FF1 256 x 257

# sample CRNN model architecture with LSTM

#SpeechEnhanceCRNN(
#  (conv1): Conv2d(3, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
#  (batch_norm1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
#  (maxpool1): MaxPool2d(kernel_size=(1, 4), stride=(1, 4), padding=0, dilation=1, ceil_mode=False)
#  (conv2): Conv2d(32, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
#  (batch_norm2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
#  (maxpool2): MaxPool2d(kernel_size=(1, 4), stride=(1, 4), padding=0, dilation=1, ceil_mode=False)
#  (conv3): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
#  (batch_norm3): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
#  (maxpool3): MaxPool2d(kernel_size=(1, 4), stride=(1, 4), padding=0, dilation=1, ceil_mode=False)
#  (rnn): LSTM(256, 256, batch_first=True)
#  (ff): Linear(in_features=256, out_features=257, bias=True)
#  (relu): ReLU()
#  (tanh): Tanh()
#  (sigmoid): Sigmoid()
#)




class SpeechEnhanceCRNN(nn.Module):
    def __init__(self, rnn_type, hirarchial,inchannel=3, filters=[32,64,64], kernel_size=3, padding=1, stride=1, maxpool_size=(1,4), rnn_hidden_size=256, rnn_input_size=256, output_size=257, num_rnn_layers=2, bidirectional=True):
        super(SpeechEnhanceCRNN, self).__init__()
        
        self.inchannel = inchannel #3
        self.num_rnn_layers = num_rnn_layers #2
        self.filters = filters  #[32, 64, 64]
        self.kernel_size = kernel_size #3
        self.padding = padding #1
        self.stride = stride #1
        self.maxpool_size = maxpool_size #(1,4)
        self.rnn_hidden_size = rnn_hidden_size #256
        self.rnn_input_size = rnn_input_size #256
        self.output_size = output_size #257
        self.bidirectional = bidirectional
        self.rnn_type = rnn_type
        self.hirarchial = hirarchial
        
        self.conv1 = nn.Conv2d(self.inchannel, self.filters[0], self.kernel_size, stride=self.stride, padding=self.padding)
        self.batch_norm1 = nn.BatchNorm2d(self.filters[0])
        self.maxpool1 = nn.MaxPool2d(self.maxpool_size)
        
        self.conv2 = nn.Conv2d(self.filters[0], self.filters[1], self.kernel_size, stride=self.stride, padding=self.padding)
        self.batch_norm2 = nn.BatchNorm2d(self.filters[1])
        self.maxpool2 = nn.MaxPool2d(self.maxpool_size)

        self.conv3 = nn.Conv2d(self.filters[1], self.filters[2], self.kernel_size, stride=self.stride, padding=self.padding)
        self.batch_norm3 = nn.BatchNorm2d(self.filters[2])
        self.maxpool3 = nn.MaxPool2d(self.maxpool_size)

        if self.rnn_type == 'LSTM':
            self.rnn = nn.LSTM(self.rnn_input_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=bool(self.bidirectional))
            
        else:
            self.rnn = nn.GRU(self.rnn_input_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=bool(self.bidirectional))
            
        
        if bool(self.bidirectional) == True:
            self.ff = nn.Linear(self.rnn_hidden_size*2, self.output_size)
        else:
            self.ff = nn.Linear(self.rnn_hidden_size, self.output_size)
            
        if bool(self.hirarchial) == True:
            if self.rnn_type == 'LSTM':
                self.rnn2 = nn.LSTM(self.output_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=bool(self.bidirectional))
            else:
                self.rnn2 = nn.GRU(self.output_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=bool(self.bidirectional))
            
            if bool(self.bidirectional) == True:
                self.ff2 = nn.Linear(self.rnn_hidden_size*2, self.output_size)
            else:
                self.ff2 = nn.Linear(self.rnn_hidden_size, self.output_size)
            
        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()
        self.sigmoid = nn.Sigmoid()


        
    def forward(self, x): # input : 1 x 3 x 21 x 257
        
        x = self.conv1(x)
        x = self.batch_norm1(x) 
        #print(x.shape) # torch.Size([1, 32, 21, 257])
        x = self.maxpool1(x)
        #print(x.shape) # torch.Size([1, 32, 21, 64])
        x = self.relu(x)

        x = self.conv2(x)
        x = self.batch_norm2(x)
        #print(x.shape) #torch.Size([1, 64, 21, 64])
        x = self.maxpool2(x)
        #print(x.shape)# torch.Size([1, 64, 21, 16])
        x = self.relu(x)

        x = self.conv3(x)
        x = self.batch_norm3(x)
        #print(x.shape) # torch.Size([1, 64, 21, 16])
        x = self.maxpool3(x)
        #print(x.shape) torch.Size([1, 64, 21, 4])
        x = self.relu(x)

        x = x.permute(0,2,1,3)
        x = x.reshape(x.shape[0], x.shape[1], x.shape[2]*x.shape[3])

        #self.rnn.flatten_parameters()
        if self.rnn_type == 'LSTM':
            _,(x,_) = self.rnn(x)
        else:
            _, x = self.rnn(x)
        
        
        #print(x[-2:].shape) #torch.Size([4, 1, 256]) torch.Size([2, 100, 256])
        #x = x[-1]
        
        if self.bidirectional == True:
            x = x[-2:].reshape(x[-2:].shape[1], 1,x[-2:].shape[0]*x[-2:].shape[2])
        else:
            x = x[-1:].reshape(x[-1:].shape[1], 1,x[-1:].shape[0]*x[-1:].shape[2])
        x = self.ff(x)
        x = self.sigmoid(x)
        #print(x.shape) #torch.Size([1, 257])
        
        if self.hirarchial == True:
            x, _ = self.rnn2(x)
            x = self.ff2(x)
            x = self.sigmoid(x)
        
        return x.unsqueeze(1) # batch_size x 1 x nframe x input_size
    



class Self_Attn(nn.Module):
    """ Self attention Layer"""
    def __init__(self, in_ch, in_dim):
        super(Self_Attn,self).__init__()
               
        self.conv = nn.Conv2d(in_channels = in_ch , out_channels = in_dim , kernel_size= 1)
        
        self.query_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim//3 , kernel_size= 1)
        self.key_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim//3 , kernel_size= 1)
        self.value_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim , kernel_size= 1)
        self.gamma = nn.Parameter(torch.zeros(1))

        self.softmax  = nn.Softmax(dim=-1) #
    def forward(self,x):
        """
            inputs :
                x : input feature maps( B X C X W X H)
            returns :
                out : self attention value + input feature 
                attention: B X N X N (N is Width*Height)
        """
        
        x = self.conv(x)
        
        m_batchsize,C,width ,height = x.size()
        
        proj_query  = self.query_conv(x).view(m_batchsize,-1,width*height).permute(0,2,1) # B X CX(N)
        proj_key =  self.key_conv(x).view(m_batchsize,-1,width*height) # B X C x (*W*H)
        
        energy =  torch.bmm(proj_query,proj_key) # transpose check
        attention = self.softmax(energy) # BX (N) X (N) 
        proj_value = self.value_conv(x).view(m_batchsize,-1,width*height) # B X C X N

        out = torch.bmm(proj_value,attention.permute(0,2,1))
        #print(out.shape)
        out = out.view(m_batchsize,C,width,height)
        print(out.shape)
        out = self.gamma*out + x
        return out


class SpeechEnhanceSelfAttentionCRNN(nn.Module):
    def __init__(self, rnn_type, hirarchial, self_attention=False, inchannel=3, filters=[32,64,64], kernel_size=3, padding=1, stride=1, maxpool_size=(1,4), rnn_hidden_size=256, rnn_input_size=256, output_size=257, num_rnn_layers=2, bidirectional=True):
        super(SpeechEnhanceSelfAttentionCRNN, self).__init__()
        
        self.inchannel = inchannel #3
        self.num_rnn_layers = num_rnn_layers #2
        self.filters = filters  #[32, 64, 64]
        self.kernel_size = kernel_size #3
        self.padding = padding #1
        self.stride = stride #1
        self.maxpool_size = maxpool_size #(1,4)
        self.rnn_hidden_size = rnn_hidden_size #256
        self.rnn_input_size = rnn_input_size #256
        self.output_size = output_size #257
        self.bidirectional = bidirectional
        self.rnn_type = rnn_type
        self.hirarchial = hirarchial
        self.self_attention = self_attention
        
        if bool(self.self_attention) == True:
            self.conv1 = Self_Attn(self.inchannel, 3)
        else:
            self.conv1 = nn.Conv2d(self.inchannel, self.filters[0], self.kernel_size, stride=self.stride, padding=self.padding)
        
        self.batch_norm1 = nn.BatchNorm2d(self.filters[0])
        self.maxpool1 = nn.MaxPool2d(self.maxpool_size)
        
        self.conv2 = nn.Conv2d(self.filters[0], self.filters[1], self.kernel_size, stride=self.stride, padding=self.padding)
        self.batch_norm2 = nn.BatchNorm2d(self.filters[1])
        self.maxpool2 = nn.MaxPool2d(self.maxpool_size)

        self.conv3 = nn.Conv2d(self.filters[1], self.filters[2], self.kernel_size, stride=self.stride, padding=self.padding)
        self.batch_norm3 = nn.BatchNorm2d(self.filters[2])
        self.maxpool3 = nn.MaxPool2d(self.maxpool_size)

        if self.rnn_type == 'LSTM':
            self.rnn = nn.LSTM(self.rnn_input_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=self.bidirectional)
            
        else:
            self.rnn = nn.GRU(self.rnn_input_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=self.bidirectional)
            
        
        if self.bidirectional == 1:
            self.ff = nn.Linear(self.rnn_hidden_size*2, self.output_size)
        else:
            self.ff = nn.Linear(self.rnn_hidden_size, self.output_size)
            
        if self.hirarchial == 1:
            if self.rnn_type == 'LSTM':
                self.rnn2 = nn.LSTM(self.rnn_input_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=self.bidirectional)
            else:
                self.rnn2 = nn.GRU(self.rnn_input_size, self.rnn_hidden_size, self.num_rnn_layers, batch_first=True, bidirectional=self.bidirectional)
            
            if self.bidirectional == True:
                self.ff2 = nn.Linear(self.rnn_hidden_size*2, self.output_size)
            else:
                self.ff2 = nn.Linear(self.rnn_hidden_size, self.output_size)
            
        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()
        self.sigmoid = nn.Sigmoid()


        
    def forward(self, x): # input : 1 x 3 x 21 x 257
        
        x = self.conv1(x)
        print(x.shape)
        x = self.batch_norm1(x)
        #print(x.shape) # torch.Size([1, 32, 21, 257])
        x = self.maxpool1(x)
        #print(x.shape) # torch.Size([1, 32, 21, 64])
        x = self.relu(x)

        x = self.conv2(x)
        x = self.batch_norm2(x)
        #print(x.shape) #torch.Size([1, 64, 21, 64])
        x = self.maxpool2(x)
        #print(x.shape)# torch.Size([1, 64, 21, 16])
        x = self.relu(x)

        x = self.conv3(x)
        x = self.batch_norm3(x)
        #print(x.shape) # torch.Size([1, 64, 21, 16])
        x = self.maxpool3(x)
        #print(x.shape) torch.Size([1, 64, 21, 4])
        x = self.relu(x)

        x = x.permute(0,2,1,3)
        x = x.reshape(x.shape[0], x.shape[1], x.shape[2]*x.shape[3])

        #self.rnn.flatten_parameters()
        if self.rnn_type == 'LSTM':
            _,(x,_) = self.rnn(x)
        else:
            _, x = self.rnn(x)
        
        
        #print(x[-2:].shape) #torch.Size([4, 1, 256]) torch.Size([2, 100, 256])
        #x = x[-1]
        
        if self.bidirectional == True:
            x = x[-2:].reshape(x[-2:].shape[1], 1,x[-2:].shape[0]*x[-2:].shape[2])
        else:
            x = x[-1:].reshape(x[-1:].shape[1], 1,x[-1:].shape[0]*x[-1:].shape[2])
        x = self.ff(x)
        x = self.sigmoid(x)
        #print(x.shape) #torch.Size([1, 257])
        
        if self.hirarchial == True:
            x, _ = self.rnn2(x)
            x = self.ff2(x)
            x = self.sigmoid(x)
        
        return x.unsqueeze(1) # batch_size x 1 x nframe x input_size
    
    


    

#y_stft = torch.rand(100,3,21,257)
#mask = model(y_stft)
#mask.shape

#model_gru =  SpeechEnhanceCRNN('GRU', False, bidirectional=False)
#model_bigru = SpeechEnhanceCRNN('GRU', False, bidirectional=True)
#model_lstm = SpeechEnhanceCRNN('LSTM', False, bidirectional=False)
#model_blstm = SpeechEnhanceCRNN('LSTM', False, bidirectional=True)
#model_hirarchial_blstm = SpeechEnhanceCRNN('LSTM', False, bidirectional=True)
#model_hirarchial_gru = SpeechEnhanceCRNN('GRU', False, bidirectional=True)





#model_bigru(y_stft).shape
#model_lstm(y_stft).shape
#model_hirarchial_blstm(y_stft).shape
#model_hirarchial_gru(y_stft).shape
#model_blstm(y_stft).shape
#model_gru(y_stft).shape




